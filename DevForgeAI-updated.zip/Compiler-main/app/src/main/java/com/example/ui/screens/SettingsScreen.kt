package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.core.preferences.IdePreferences
import com.example.core.preferences.OnlineProviderType
import com.example.core.security.SigningKeyInfo
import com.example.ui.components.IdePanel
import com.example.ui.components.IdeSectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalIdeColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
  preferences: IdePreferences,
  signingKeyInfo: SigningKeyInfo?,
  onSetDarkTheme: (Boolean) -> Unit,
  onSaveEditorSettings: (Int, Int, Boolean, Boolean) -> Unit,
  onSaveOnlineConfig: (OnlineProviderType, String, String, String?) -> Unit,
  onClearApiKey: () -> Unit,
  onSetAllowCodeUpload: (Boolean) -> Unit,
  onSaveCustomToolchainPath: (String) -> Unit,
  onEnsureSigningKey: () -> Unit,
) {
  val ideColors = LocalIdeColors.current
  var fontSize by remember(preferences.editorFontSizeSp) { mutableIntStateOf(preferences.editorFontSizeSp) }
  var tabSize by remember(preferences.editorTabSize) { mutableIntStateOf(preferences.editorTabSize) }
  var wordWrap by remember(preferences.editorWordWrap) { mutableStateOf(preferences.editorWordWrap) }
  var autoSave by remember(preferences.autoSaveEnabled) { mutableStateOf(preferences.autoSaveEnabled) }
  var provider by remember(preferences.onlineProvider) { mutableStateOf(preferences.onlineProvider) }
  var modelId by remember(preferences.onlineModelId) { mutableStateOf(preferences.onlineModelId) }
  var endpointUrl by remember(preferences.customEndpointUrl) { mutableStateOf(preferences.customEndpointUrl) }
  var apiKeyInput by remember { mutableStateOf("") }
  var notice by remember { mutableStateOf<String?>(null) }
  var toolchainPath by remember(preferences.customToolchainPath) { mutableStateOf(preferences.customToolchainPath) }

  LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item {
      IdePanel(Modifier.fillMaxWidth()) {
        IdeSectionHeader(title = "APPEARANCE & CODE EDITOR")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Dark Developer IDE Theme"); Switch(preferences.darkTheme, onSetDarkTheme, modifier = Modifier.testTag("settings_dark_theme_switch"))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Word Wrap"); Switch(wordWrap, { wordWrap = it })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Auto-save"); Switch(autoSave, { autoSave = it })
        }
        Text("Editor font size: ${fontSize}sp"); Slider(fontSize.toFloat(), { fontSize = it.toInt() }, valueRange = 10f..22f)
        Text("Tab width: $tabSize spaces"); Slider(tabSize.toFloat(), { tabSize = it.toInt() }, valueRange = 2f..8f)
        Button(onClick = { onSaveEditorSettings(fontSize, tabSize, wordWrap, autoSave) }) { Text("Apply Editor Settings") }
      }
    }
    item {
      IdePanel(Modifier.fillMaxWidth()) {
        IdeSectionHeader(title = "AI API CONFIGURATION")
        Text("Connect any supported provider or an OpenAI-compatible API. Local AI models have been removed.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Text("Provider", style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          OnlineProviderType.entries.forEach { item ->
            FilterChip(selected = provider == item, onClick = { provider = item; modelId = item.defaultModel; endpointUrl = item.defaultBaseUrl }, label = { Text(item.displayName) })
          }
        }
        OutlinedTextField(value = endpointUrl, onValueChange = { endpointUrl = it }, label = { Text("API Base URL") }, placeholder = { Text("https://your-provider.com/v1") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("settings_api_base_url"))
        OutlinedTextField(value = modelId, onValueChange = { modelId = it }, label = { Text("Model ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = apiKeyInput, onValueChange = { apiKeyInput = it }, label = { Text(if (preferences.hasApiKey) "API Key (saved; enter to replace)" else "Paste API Key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth().testTag("settings_api_key_input"))
        Text("Your key is encrypted before it is saved on this device.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
          Button(onClick = { onSaveOnlineConfig(provider, modelId, endpointUrl, apiKeyInput.takeIf { it.isNotBlank() }); apiKeyInput = ""; notice = "API configuration saved" }, modifier = Modifier.testTag("settings_save_ai_btn")) { Text("Save API Settings") }
          if (preferences.hasApiKey) OutlinedButton(onClick = { onClearApiKey(); notice = "Saved API key cleared" }) { Text("Clear key") }
        }
        notice?.let { Text(it, color = ideColors.success, style = MaterialTheme.typography.labelSmall) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Allow AI to read project source files", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
          Switch(preferences.allowUploadingProjectFilesToOnlineAi, onSetAllowCodeUpload)
        }
        StatusPill(text = if (preferences.hasApiKey) "API KEY SAVED" else "API KEY REQUIRED", color = if (preferences.hasApiKey) ideColors.success else MaterialTheme.colorScheme.error)
      }
    }
    item {
      IdePanel(Modifier.fillMaxWidth()) {
        IdeSectionHeader(title = "CUSTOM TOOLCHAIN & SIGNING KEYSTORE")
        OutlinedTextField(value = toolchainPath, onValueChange = { toolchainPath = it }, label = { Text("Extra executable PATH") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { onSaveCustomToolchainPath(toolchainPath) }) { Text("Save Toolchain Path") }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Release Signing Key"); StatusPill(text = if (signingKeyInfo != null) "KEY READY" else "UNCHECKED", color = if (signingKeyInfo != null) ideColors.success else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        signingKeyInfo?.let { Text("Alias: ${it.alias}\nSHA-256: ${it.sha256Fingerprint}", style = MaterialTheme.typography.labelSmall) }
        OutlinedButton(onClick = onEnsureSigningKey) { Text("Generate / Inspect Keystore Key") }
      }
    }
  }
}
